
# THIS FILE IS GENERATED FROM MECHELASTIC SETUP.PY.
name = 'MechElastic'
version = '1.1.15'
description = 'A Python library to calculate elastic properties of materials. '
url = 'https://github.com/romerogroup/MechElastic'
author = 'Sobhit Singh'
email = 'smsingh@mail.wvu.edu'
status = 'development'
copyright = 'Copyright 2020'
date = 'Aug 12th, 2020'
