
# THIS FILE IS GENERATED FROM MECHELASTIC SETUP.PY.
name = 'MechElastic'
version = '1.1.9'
description = 'A Python library to calculate elastic properties of materials. '
url = 'https://github.com/romerogroup/MechElastic'
author = 'Sobhit Singh'
email = 'smsingh@mail.wvu.edu'
status = 'development'
copyright = 'Copyright 2020'
date = 'July 29th, 2020'
