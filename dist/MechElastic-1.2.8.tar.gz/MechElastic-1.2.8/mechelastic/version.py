
# THIS FILE IS GENERATED FROM MECHELASTIC SETUP.PY.
name = 'MechElastic'
version = '1.2.8'
description = 'A Python library to calculate elastic properties of materials. '
url = 'https://github.com/romerogroup/MechElastic'
author = 'Sobhit Singh, Logan Lang, Viviana Dovale-Farelo, Uthpala Herath, Pedram Tavadze, François-Xavier Coudert, Aldo H. Romero'
email = 'smsingh@mail.wvu.edu'
status = 'development'
copyright = 'Copyright 2021'
date = 'Jan 9th, 2021'
